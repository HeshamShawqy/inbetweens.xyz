import pandas as pd
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow,Flow
from google.auth.transport.requests import Request
import os
import pickle
import numpy as np
import seaborn as sns
import altair as alt
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow import keras
import joblib

"""**1) READ THE LIVE EXCEL SHEET EXPORTED BY MAPBOX**"""

#get spreadsheets key from url
gsheetkey = "1xRlq_u0tQBpJb5gRFcZWlFcWspo-hVDMgGMNeDo4_po"

url=f'https://docs.google.com/spreadsheet/ccc?key={gsheetkey}&output=xlsx'
data = pd.read_excel(url)



"""**FROM HERE, THE DATA IS READY TO START PREDICTING:**"""

#make a copy of the data and drop everything that is not important for the ML. rename the collums to match the ones from train
data_copy = data.copy()

#['Name', 'Quality', "Type", 'Happiness', 'Comment', 'IP', "Node index", "Frequency_visits_type" , "Frequency_visits"]
data_copy.rename(columns={"Lattitude": "x", "Longitude": "y"}, inplace=True)

#add an empty collum for the empty space id
data_copy['id'] = pd.Series(dtype='int')


#_________________________________________________________________

"""**2) USE THE TRAINED ML TO PREDICT EMPTY SPACE IDS**"""

#load the ml trained model
#load the scaler

pred_model = tf.keras.models.load_model("STUDIO-ML_CATEGORIZATION_MODEL_V1.h5")


# File path
filepath = "STUDIO-ML_CATEGORIZATION_MODEL_V1.h5"

# Load the model
model = tf.keras.models.load_model(filepath, compile = True)
scalerX = joblib.load("scalerX_classification.save") 



# Iterate through the sheet, take the x // y point coordinates, and pass it to the ML model

samples_to_predict = []
for index, row in data_copy.iterrows():
  values = data_copy.iloc[index]['x'], data_copy.iloc[index]['y']
  samples_to_predict.append(values)

samples_scaled = scalerX.fit_transform(samples_to_predict)

samples_to_predict = np.array(samples_scaled)



# Generate predictions for samples
predictions = model.predict(samples_to_predict)
classes = np.argmax(predictions, axis = 1)
#print(classes)

#give the predictions to the original data

data["id"]=classes


#make new empty columns for each type label
new_data = data
new_data["Public"]= pd.Series(dtype='int')
new_data["Health"]= pd.Series(dtype='int')
new_data["Infrastructure"]= pd.Series(dtype='int')
new_data["Education"]= pd.Series(dtype='int')

#write in each colum a 1 if its true, a 0 if its false for each point
for index, row in new_data.iterrows():

  if new_data.loc[index, "Type"] == "Public":
    new_data.loc[index, "Public"]  = 1
    new_data.loc[index, "Health"]  = 0
    new_data.loc[index, "Infrastructure"]  = 0
    new_data.loc[index, "Education"]  = 0

  if new_data.loc[index, "Type"] == "Health":
    new_data.loc[index, "Public"]  = 0
    new_data.loc[index, "Health"]  = 1
    new_data.loc[index, "Infrastructure"]  = 0
    new_data.loc[index, "Education"]  = 0

  if new_data.loc[index, "Type"] == "Infrastructure":
    new_data.loc[index, "Public"]  = 0
    new_data.loc[index, "Health"]  = 0
    new_data.loc[index, "Infrastructure"]  = 1
    new_data.loc[index, "Education"]  = 0

  if new_data.loc[index, "Type"] == "Education":
    new_data.loc[index, "Public"]  = 0
    new_data.loc[index, "Health"]  = 0
    new_data.loc[index, "Infrastructure"]  = 0
    new_data.loc[index, "Education"]  = 1


#group the data by empty space ID
grouped_data = new_data.groupby(['id']).sum()
print(grouped_data.head(5))
grouped_data.drop(columns=['Lattitude', 'Longitude'], inplace=True)
grouped_data["Public"] = grouped_data["Public"].astype(int)
grouped_data["Health"] = grouped_data["Health"].astype(int)
grouped_data["Infrastructure"] = grouped_data["Infrastructure"].astype(int)
grouped_data["Education"] = grouped_data["Education"].astype(int)

grouped_data.head(3)
#grouped_data.to_csv(r"C:\Users\joao-\OneDrive\Ambiente de Trabalho\17-18\GRASSHOPPER\IAAC\SEMESTRE 2\Studio\HOPSGrouped_Data_test.csv", index = True)
#add a collum that show how many close points there is in total
grouped_data['Num_Points_Close']= data['id'].value_counts()

final_data = grouped_data.sort_values(by=['Num_Points_Close'], ascending=False)

def activate(label,num_points):
    print("FUNCION CALLED")
    num_points = int(float(num_points))
    sortedlist = final_data.sort_values(by=[label, "Num_Points_Close"], ascending=False)

    index_list = sortedlist.index
    return_list = []
    for item in index_list:
      return_list.append(item)
    return_list_final = return_list[:num_points]
    print("LISTA DE RETURN!!!")
    print(return_list_final)
    return return_list_final
    

#final_data.to_csv("/content/Activated_spaces_IDs.csv", index = True)
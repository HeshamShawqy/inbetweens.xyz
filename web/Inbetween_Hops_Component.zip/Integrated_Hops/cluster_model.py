import pandas as pd
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow,Flow
from google.auth.transport.requests import Request
import os
import pickle
import numpy as np
import seaborn as sns
import altair as alt
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow import keras
import joblib
from sklearn.cluster import KMeans

#get spreadsheets key from url
gsheetkey = "1xRlq_u0tQBpJb5gRFcZWlFcWspo-hVDMgGMNeDo4_po"
url=f'https://docs.google.com/spreadsheet/ccc?key={gsheetkey}&output=xlsx'
data = pd.read_excel(url)

#make a copy of the data and drop everything that is not important for the ML. rename the collums to match the ones from train
data_copy = data.copy()


#drop and rename some columns

data_copy.rename(columns={"Lattitude": "x", "Longitude": "y"}, inplace=True)

#add an empty collum for the empty space id
data_copy['id'] = pd.Series(dtype='int')
data_copy['dis'] = pd.Series(dtype='float')

#load the ml trained model fro CATEGORIZATION
filepath = "STUDIO-ML_CATEGORIZATION_MODEL_V1.h5"
model = tf.keras.models.load_model(filepath, compile = True)
scalerX = joblib.load("scalerX_classification.save") 

# Iterate through the sheet, take the x // y point coordinates, and pass it to the ML model
samples_to_predict = []
for index, row in data_copy.iterrows():
  values = data_copy.iloc[index]['x'], data_copy.iloc[index]['y']
  samples_to_predict.append(values)

samples_scaled = scalerX.fit_transform(samples_to_predict)
samples_to_predict = np.array(samples_scaled)

# Generate predictions for samples
predictions = model.predict(samples_to_predict)
classes = np.argmax(predictions, axis = 1)

#give the predictions to the original data
data_copy["id"]=classes
data_copy.head(3)

#load the ml trained model fOR REGRESSION
filepath = "STUDIO-ML_REGRESSION_MODEL_V1.h5"
model = tf.keras.models.load_model(filepath, compile = True)
scalerX = joblib.load("scalerX_regression.save") 
scalerY = joblib.load("scalerY_regression.save") 

# Iterate through the sheet, take the x, y and id, and pass it to the ML model

samples_to_predict = []
for index, row in data_copy.iterrows():
  values = data_copy.iloc[index]['x'], data_copy.iloc[index]['y'], data_copy.iloc[index]['id']
  samples_to_predict.append(values)

samples_scaled = scalerX.fit_transform(samples_to_predict)
samples_to_predict = np.array(samples_scaled)

# Pass them to the model to predict distance
predictions = model.predict(samples_to_predict)
predictions = predictions.reshape(-1, 1)
y_truth = scalerY.inverse_transform(predictions)

#give the predictions to the original data
data_copy["dis"]=y_truth

#make new empty columns for each type label
new_data = data_copy
new_data["Public"]= pd.Series(dtype='int')
new_data["Health"]= pd.Series(dtype='int')
new_data["Infrastructure"]= pd.Series(dtype='int')
new_data["Education"]= pd.Series(dtype='int')


#make new empty columns for each type label distance

new_data["Dis_Public"]= pd.Series(dtype='float')
new_data["Dis_Health"]= pd.Series(dtype='float')
new_data["Dis_Infrastructure"]= pd.Series(dtype='float')
new_data["Dis_Education"]= pd.Series(dtype='float')


#THIS TO MAKE THE TYPES OF POINTS_CLOSE COLUMNS
#write in each colum a 1 if its true, a 0 if its false for each point
for index, row in new_data.iterrows():

  if new_data.loc[index, "Type"] == "Public":
    new_data.loc[index, "Public"]  = 1
    new_data.loc[index, "Health"]  = 0
    new_data.loc[index, "Infrastructure"]  = 0
    new_data.loc[index, "Education"]  = 0

  if new_data.loc[index, "Type"] == "Health":
    new_data.loc[index, "Public"]  = 0
    new_data.loc[index, "Health"]  = 1
    new_data.loc[index, "Infrastructure"]  = 0
    new_data.loc[index, "Education"]  = 0

  if new_data.loc[index, "Type"] == "Infrastructure":
    new_data.loc[index, "Public"]  = 0
    new_data.loc[index, "Health"]  = 0
    new_data.loc[index, "Infrastructure"]  = 1
    new_data.loc[index, "Education"]  = 0

  if new_data.loc[index, "Type"] == "Education":
    new_data.loc[index, "Public"]  = 0
    new_data.loc[index, "Health"]  = 0
    new_data.loc[index, "Infrastructure"]  = 0
    new_data.loc[index, "Education"]  = 1
  

#THIS TIME TO MAKE THE DISTANCE COLUMNS
#write in each colum a 1 if its true, a 0 if its false for each point
for index, row in new_data.iterrows():
  if new_data.loc[index, "Type"] == "Public":
    new_data.loc[index, "Dis_Public"]  = new_data.loc[index, "dis"]

  if new_data.loc[index, "Type"] == "Health":
    new_data.loc[index, "Dis_Health"]  = new_data.loc[index, "dis"]

  if new_data.loc[index, "Type"] == "Infrastructure":
    new_data.loc[index, "Dis_Infrastructure"]  = new_data.loc[index, "dis"]

  if new_data.loc[index, "Type"] == "Education":
    new_data.loc[index, "Dis_Education"]  = new_data.loc[index, "dis"]

#group the data by empty space ID
grouped_data = new_data.groupby(['id']).sum()
grouped_data.drop(columns=['x', 'y', "dis"], inplace=True)
grouped_data["Public"] = grouped_data["Public"].astype(int)
grouped_data["Health"] = grouped_data["Health"].astype(int)
grouped_data["Infrastructure"] = grouped_data["Infrastructure"].astype(int)
grouped_data["Education"] = grouped_data["Education"].astype(int)
#grouped_data = grouped_data.set_index('id')
test_data = grouped_data


#QUANTATIES PERCENTAGES
df_quant = test_data[['Public', "Health", "Infrastructure", "Education"]]
col_list= list(df_quant)

for index, row in df_quant.iterrows():
  #total
  total = df_quant[col_list].sum(axis=1)
  #por categoria
  public = df_quant["Public"] / total * 100
  public2 = public.apply(pd.to_numeric, errors='coerce')
  public_percentage = round(public2)
  test_data["Public"] = public_percentage

  public = df_quant["Health"] / total * 100
  public2 = public.apply(pd.to_numeric, errors='coerce')
  public_percentage = round(public2)
  test_data["Health"] = public_percentage

  public = df_quant["Infrastructure"] / total * 100
  public2 = public.apply(pd.to_numeric, errors='coerce')
  public_percentage = round(public2)
  test_data["Infrastructure"] = public_percentage

  public = df_quant["Education"] / total * 100
  public2 = public.apply(pd.to_numeric, errors='coerce')
  public_percentage = round(public2)
  test_data["Education"] = public_percentage

#FEATURES REMAP

df_features = test_data[['Quality', "Accessibility", "Frequency"]]

print(col_list)
for index, row in df_features.iterrows():
  num_points = df_quant[col_list].sum(axis=1)
  #scores
  old_max = num_points * 3 
  old_min = num_points * 1
  qual_score = df_features["Quality"]
  acces_score = df_features["Accessibility"] 
  freq_score = df_features["Frequency"] 

  new_min = 0 
  new_max = 10 
  new_qual = ( (qual_score - old_min) / (old_max - old_min) ) * (new_max - new_min) + new_min
  test_data["Quality"] = new_qual

  new_acces = ( (acces_score - old_min) / (old_max - old_min) ) * (new_max - new_min) + new_min
  test_data["Accessibility"] = new_acces

  new_freq = ( (freq_score - old_min) / (old_max - old_min) ) * (new_max - new_min) + new_min
  test_data["Frequency"] = new_freq

cluster_data = test_data

def cluster():
    print("FUNCION CALLED")
    #num_points = int(float(num_points))
    #sortedlist = final_data.sort_values(by=[label, "Num_Points_Close"], ascending=False)
    #x = grouped_data[['Public', 'Health', "Infrastructure", "Education"]]
    x = cluster_data[['Public', 'Health', "Infrastructure", "Education", "Quality", "Accessibility", "Frequency"]]
    kmeans4 = KMeans(n_clusters=4)
    y_kmeans4 = kmeans4.fit_predict(x)

#kmeans8.cluster_centers_
    
    #add the clusters numbers to the table
    cluster_data["Cluster"] = y_kmeans4

    ListA= cluster_data.index.values
    listA = []
    for value in ListA:
      listA.append(value)
    cluster_data["IDs"] = listA  
    
    filter0 = cluster_data[cluster_data["Cluster"]==0]
    filter1 = cluster_data[cluster_data["Cluster"]==1]
    filter2 = cluster_data[cluster_data["Cluster"]==2]
    filter3 = cluster_data[cluster_data["Cluster"]==3]
    
    lista0 = filter0['IDs'].tolist()
    lista1 = filter1['IDs'].tolist()
    lista2 = filter2['IDs'].tolist()
    lista3 = filter3['IDs'].tolist()
    
    return_list= []
    return_list.append(lista0)
    return_list.append(lista1)
    return_list.append(lista2)
    return_list.append(lista3)

    #return_lists
    print("LISTA DE RETURN!!!")
    return return_list


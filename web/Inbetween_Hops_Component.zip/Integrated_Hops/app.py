# x, y = utm.from_latlon(input_lat, input_lon)
from mclp import *
import inbetween_model
import cluster_model

import numpy as np
import pandas as pd
from scipy.spatial import distance_matrix
from gurobipy import *
from scipy.spatial import ConvexHull
from shapely.geometry import Polygon, Point
from numpy import random
from flask import Flask
import ghhops_server as hs
import rhino3dm


app = Flask(__name__)
hops = hs.Hops(app)

#__________________________________________
#get all the points by label
gsheetkey = "1xRlq_u0tQBpJb5gRFcZWlFcWspo-hVDMgGMNeDo4_po"
url=f'https://docs.google.com/spreadsheet/ccc?key={gsheetkey}&output=xlsx'
data = pd.read_excel(url)

point_list = []
label2 = "Public" #CHOOSE THE LABEL

for index, row in data.iterrows():
    if data.loc[index, "Type"] == label2:
        values = data.iloc[index]['Lattitude'], data.iloc[index]['Longitude']
        point_list.append(values)

points = np.asarray(point_list)

#get the empty space list
space_data = pd.read_csv("just_empty_spaces.csv")
print("SPACE DATA")
print(space_data.head(5))
space_points_list =  []
for index, row in space_data.iterrows():
    values = space_data.iloc[index]['NODES X CO'], space_data.iloc[index]['NODES Y CO']
    space_points_list.append(values)

space_points = np.asarray(space_points_list)




#__________________/maxcov____________________________

@hops.component(
     "/maxcov",
     name="Maximum Coverage",
     description="Get the features, output the predictions",
     icon="examples/pointat.png",
     inputs=[
         hs.HopsNumber("num_points", "NumberPointsWanted", "Number of activated points wanted"),
         hs.HopsString("label2", "label2", "wanted label")
     ],
     outputs=[
         hs.HopsNumber("maxcov", "maxcov", "ML activated points")
     ]
)


def maxcov(num_points, label2):
    print("MAXCOV CALLED")
    num_points = int(num_points)
    # Number of sites to select
    K = num_points
    # Service radius of each site
    radius = 0.001
    # Candidate site size (random sites generated)
    M = 100

    opt_sites,f = mclp(points,K, radius, M )
    plot_result (space_points, points, opt_sites, radius)
    print("opt_sites")
    print(opt_sites)

    ids = []
    ids = []
    for i in range(len(opt_sites)):
        for index, row in space_data.iterrows():
                if float(opt_sites[i][0]) == float(space_data.iloc[index]['NODES X CO']) and float(opt_sites[i][1]) == float(space_data.iloc[index]['NODES Y CO']):
                        ids.append(space_data.iloc[index]['EMPTY SPACE ID'])
                else: 
                        continue
    print(ids)    
    return ids

    #__________________/mlprediction____________________________

#__________________/mlprediction____________________________

@hops.component(
     "/mlprediction",
     name="ML_prediction",
     description="Get the features, output the predictions",
     icon="examples/pointat.png",
     inputs=[
         hs.HopsNumber("num_points", "num_points", "Number of activated points wanted"),
         hs.HopsString("label", "label", "wanted label")
         
     ],
     outputs=[
         hs.HopsNumber("activation", "activation", "ML activated points")
     ]
)

def activation(num_points,label):
    activation = inbetween_model.activate(label,num_points)
    return activation


#__________________/cluster____________________________

@hops.component(
     "/cluster",
     name="K-Means Clustering",
     description="Get the features, output the predictions",
     icon="examples/pointat.png",
     inputs=[
         #hs.HopsNumber("num_points", "num_points", "Number of activated points wanted"),
         #hs.HopsString("label", "label", "wanted label")
         
     ],
     outputs=[
         hs.HopsNumber("cluster0", "cluster0", "ML activated points"),
         hs.HopsNumber("cluster1", "cluster1", "ML activated points"),
         hs.HopsNumber("cluster2", "cluster2", "ML activated points"),
         hs.HopsNumber("cluster3", "cluster3", "ML activated points"),

     ]
)

def cluster():
    cluster = cluster_model.cluster()
    print(cluster[0])
    print(cluster[1])
    print(cluster[2])
    print(cluster[3])

    cluster0 = cluster[0]
    cluster1 = cluster[1]
    cluster2 = cluster[2]
    cluster3 = cluster[3]

    return cluster0,cluster1,cluster2,cluster3





#________________________________________
if __name__ == "__main__":
    app.run()